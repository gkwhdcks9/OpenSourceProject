using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float moveSpeed = 5f; // 캐릭터 이동 속도

    private Rigidbody rb; // Rigidbody2D 컴포넌트 참조
    private Vector3 movement; // 이동 방향 벡터
    private Animator animator; // Animator 컴포넌트 참조

    void Start()
    {
        // Rigidbody2D 컴포넌트를 가져옵니다.
        rb = GetComponent<Rigidbody>();

        // Animator 컴포넌트를 가져옵니다.
        animator = GetComponent<Animator>();
    }

    void Update()
    {
        // 플레이어 입력 처리
        float horizontal = Input.GetAxisRaw("Horizontal"); // 좌우 입력: -1 (왼쪽), 1 (오른쪽)
        float vertical = Input.GetAxisRaw("Vertical");     // 상하 입력: -1 (아래), 1 (위)

        // 대각선 방지: 수평 또는 수직 중 하나만 활성화
        if (horizontal != 0)
        {
            movement.x = horizontal;
            movement.y = 0; // 수평 입력이 우선되면 수직 입력 무시
        }
        else if (vertical != 0)
        {
            movement.x = 0; // 수직 입력이 우선되면 수평 입력 무시
            movement.y = vertical;
        }
        else
        {
            movement = Vector2.zero; // 입력이 없으면 멈춤
        }

        // 애니메이션 파라미터 업데이트
        UpdateAnimation();
    }

    void FixedUpdate()
    {
        // Rigidbody2D를 사용한 이동
        rb.MovePosition(rb.position + movement * moveSpeed * Time.fixedDeltaTime);
    }

    void UpdateAnimation()
    {
        if (animator != null)
        {
            // 애니메이션 파라미터 설정
            animator.SetFloat("Horizontal", movement.x);
            animator.SetFloat("Vertical", movement.y);
            animator.SetFloat("Speed", movement.sqrMagnitude); // 속도의 크기 (움직임 여부 판단)
        }
    }
}
